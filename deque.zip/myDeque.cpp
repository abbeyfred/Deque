#include <iostream>
#include <vector>
#include <string>
#include <cmath> // std::floor, std::ceil
#include <algorithm> // std::reverse
#include "myDeque.hpp"

template <typename T>
MyDeque<T>::MyDeque() {}

template <typename T>
MyDeque<T>::MyDeque(int n) {
  resizeVectors(n);
}

template <typename T>
MyDeque<T>::MyDeque(std::initializer_list<T> vals) {
  // Create a vector copy of vals
  std::vector<T> valsCopy(vals.size());
  int i = 0;
  for (T x : vals) {
    valsCopy[i++] = x;
  }
  // Resize and initialize vectors
  resizeVectors(valsCopy.size());
  initializeVectors(valsCopy);
}

template <typename T>
void MyDeque<T>::push_back(T val) {
  if (size() == 0) {
    frontVector.resize(1);
    frontVector[0] = val;
    return;
  }
  backVector.resize(backVector.size() + 1);
  backVector[backVector.size() - 1] = val;
}

template <typename T>
void MyDeque<T>::push_front(T val) {
  if (size() == 0) {
    frontVector.resize(1);
    frontVector[0] = val;
    return;
  }
  frontVector.resize(frontVector.size() + 1);
  // 'Reverse' frontVector i.e., the front is at the back
  frontVector[frontVector.size() - 1] = val;
}

template <typename T>
void MyDeque<T>::pop_back() {
  if (backVector.size() == 1 && frontVector.size() != 0) {
    backVector.pop_back();
    rebalance(false);
  } else if (backVector.size() == 1 && frontVector.size() == 0) {
    backVector.pop_back();
  } else if (backVector.size() == 0 && frontVector.size() != 0) {
    frontVector.pop_back();
  } else {
    backVector.resize(backVector.size() - 1);
  }
}

template <typename T>
void MyDeque<T>::pop_front() {
  if (frontVector.size() == 1 && backVector.size() != 0) {
    frontVector.pop_back();
    rebalance(true);
  } else if (frontVector.size() == 1 && backVector.size() == 0) {
    frontVector.pop_back();
  } else {
    frontVector.resize(frontVector.size() - 1);
  }
}

template <typename T>
T& MyDeque<T>::back() {
  if (size() == 1) {
    return frontVector[0];
  }
  return backVector.back();
}

template <typename T>
const T& MyDeque<T>::back() const {
  if (size() == 1) {
    return frontVector[0];
  }
  return backVector.back();
}

template <typename T>
T& MyDeque<T>::front() {
  // 'Reverse' frontVector
  return frontVector[frontVector.size() - 1];
}

template <typename T>
const T& MyDeque<T>::front() const {
  return frontVector[frontVector.size() - 1];
}

template <typename T>
bool MyDeque<T>::empty() const {
  if (size() != 0) {
    return false;
  }
  return true;
}

template <typename T>
int MyDeque<T>::size() const {
  return frontVector.size() + backVector.size();
}

template <typename T>
T& MyDeque<T>::operator[](int i) {
  std::size_t index = i;
  if (index < frontVector.size()) {
    // 'Reverse' frontVector
    return frontVector[frontVector.size() - index - 1];
  } else if (index == frontVector.size()) {
    return backVector[0];
  } else {
    return backVector[index - frontVector.size()];
  }
}

template <typename T>
const T& MyDeque<T>::operator[](int i) const {
  std::size_t index = i;
  if (index < frontVector.size()) {
    return frontVector[frontVector.size() - index - 1];
  } else if (index == frontVector.size()) {
    return backVector[0];
  } else {
    return backVector[index - frontVector.size()];
  }
}

template <typename T>
void MyDeque<T>::resizeVectors(int size) {
  if (size == 1) { // Size is one
    frontVector.resize(1);
  } else if (size % 2 != 0) { // Size is not one and odd
    frontVector.resize(std::floor(static_cast<double>(size)/2));
    backVector.resize(std::ceil(static_cast<double>(size)/2));
  } else { // Size is even
    frontVector.resize(size/2);
    backVector.resize(size/2);
  }
}

template <typename T>
void MyDeque<T>::initializeVectors(std::vector<T> vec) {
  // Initialize frontVector in 'reverse' order
  std::size_t j = frontVector.size() - 1;
  for (std::size_t i = 0; i < frontVector.size(); ++i) {
    frontVector[i] = vec[j];
    --j;
  }
  // Initialize backVector
  std::size_t k = frontVector.size();
  for (std::size_t i = 0; i < backVector.size(); ++i) {
    backVector[i] = vec[k];
    ++k;
  }
}

template <typename T>
void MyDeque<T>::rebalance(bool boolean) {
  if (boolean == true) { // frontVector is empty
    // Copy backVector
    std::vector<T> backVectorCopy {backVector};
    // Clear backVector
    backVector.clear();
    // Resize and initialize vectors
    resizeVectors(backVectorCopy.size());
    initializeVectors(backVectorCopy);
  } else { // backVector is empty
    // Copy frontVector
    std::vector<T> frontVectorCopy {frontVector};
    // Clear frontVector
    frontVector.clear();
    if (frontVectorCopy.size() % 2 == 0) { // Size is even
      // Reverse elements in copy
      std::reverse(frontVectorCopy.begin(), frontVectorCopy.end());
    }
    // Resize vectors and initialize vectors
    resizeVectors(frontVectorCopy.size());
    initializeVectors(frontVectorCopy);
  }
}

template class MyDeque<int>;
template class MyDeque<double>;
template class MyDeque<char>;
template class MyDeque<std::string>;
